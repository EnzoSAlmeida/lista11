package br.ucsal.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/calculator")
public class CalculatorServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
		double dividend = Double.parseDouble(request.getParameter("dividend"));
        double divisor = Double.parseDouble(request.getParameter("divisor"));

        if (divisor == 0) {
            request.setAttribute("errorMessage", "Erro: Divisão por zero não é permitida.");
        } else {
            double result = dividend / divisor;
            request.setAttribute("result", result);
        }

        request.getRequestDispatcher("calculator.jsp").forward(request, response);
    }
}